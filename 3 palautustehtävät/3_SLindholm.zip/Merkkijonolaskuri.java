/*  Merkkijonolaskuri
 *  (C) Suvi'20
 */
import java.util.Scanner;

public class Merkkijonolaskuri {
    public static void main(String[] args) {
        Scanner lukija = new Scanner(System.in);
            
        //Kysytään käyttäjältä numeroita
        System.out.println("Syota numeroita:");
        String numerot = lukija.nextLine();

        String summa = ; //Tämä vielä kesken ja mietinnässä

        System.out.println("Summa on " + summa);
    }
    
}
